FT Customer Products Technical Exercise Response
By Paul Humphreys <>

Dependancies:
  node.js
  The npm node-fetch module (https://www.npmjs.com/package/node-fetch)

Before any web requests are made, this code validates both that the input
parameter is an array and that this array only contains strings as elements.
If either of these initial tests fail then a rejected promise is returned.

Otherwise the node-fetch module is used to request a response from each of
the url strings in the input array and this code then returns the result of
Promise.all for these calls to node-fetch.

Testing
to test this code, test.js in the same folder as this readme.md file can be
run by installing node.js then running (the node-fetch module has already
been `npm install` ed into this folder)

```
node ./test.js
```


