//if this code is loaded client side via webpack, window.fetch will already exist. If it doesn't we load the node-fetch module first
const _fetch = typeof fetch === 'function' ? fetch : require('node-fetch');

//returns an array of the indices of the input array which are not strings, or an empty array if there are none
const nonStringIndices = (accumulator, currentValue, index, array) => {
    if(typeof currentValue !== 'string') {
        accumulator.push(index);
    }

    return accumulator;
}

const responseToJson = response => response.json();
const requestAllUrls = item => _fetch(item).then(responseToJson);

module.exports = urls => {
    if(!Array.isArray(urls)) {
        return Promise.reject(new Error('Passed in parameter is not an array of urls as strings'));
    }

    const arrNotStrings = urls.reduce(nonStringIndices, []);

    if(arrNotStrings.length) {
        return Promise.reject(new Error('Passed in array parameter does not have urls as strings at the following indices: ' + JSON.stringify(arrNotStrings)));
    }

    // just return an array of what the fetch function would return for each member of the input array of urls.
    // Less code here is lower maintanance and more predictable for developers using this function
    return Promise.all(urls.map(requestAllUrls));
};
