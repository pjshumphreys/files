
// by Chris Born januari 2022, freeware

//     gcc mgtDD243.c -o mgtDD243  -Wall 2> mgtDD243.log       // '2>' redirects to a file
//     ./mgtDD243  MKdiskDD_0037.IMG  leeg_DISCiPLE_80.IMG

//// zcc is now compiling :)
//// zcc +zx -vn mgtDD243.c -o mgtDD243 -lesxdos -DAMALLOC2 -create-app

// this routine aims on reading a Miles Gordon Technology (MGT) *.IMG disc image as used by eg RealSpectrum emulator.
// Until now only MGT device Disciple , but not (yet?) +D disc device or SAM Coupe.
// first task is reading and displaying the directory of 4 tracks, 0-3
// on PC aka crossover disk format a common *.IMG is used for the DISCiPLE
// track side  1            track side 2
//  0 directory               128 free
//  1 directory               129 free
//  2 directory               130 free
//  3 directory               131 free
//  4 free                    132 free
//  5 free                    133 free
//  . ..                        . ..
// 79 free                    207 free
// number gab to side 2 by adding bit 7

// while images with *.MGT are the +D and Sam Coupe format.
//  while the directory IS AT 2 SIDES ??
// is the track NUMBER identical ???
// track side  1            track side 2
//  0 directory               128 directory
//  1 directory               129 directory
//  2 free                    130 free
//  3 free                    131 free
//  . ..                        . ..
// 79 free                    207 free
// number gab to side 2 by adding bit 7

// or does the track +D/SAM numbering flips side ASWELL ??
// track side  1            track side 2
//  0 directory                1 directory
//  2 directory                3 directory
//  4 free                     5 free
//  6 free                     7 free
//  . ..                        . ..
// 78 free                     79 free
// number gab  bit7           number gab bit7
//128 free                    129 free
//  . ..                        . ..
//206 free                    207 free

// todo is perhaps:
// -check the bitmap info, are sector_bitmapbits corresponding with the (track,sector) sequence?
// -select and save/extract files from disk image
// -read possible BASIC+vars from diskimage
// -snapfiles have plenty read-routines, perhaps later.
// -working on ZX+DISCiPLE itself


//http://robertp.net/Disciple/Manual/ManDisciple.htm
/* DIRECTORY DESCRIPCION
	FILE TYPE
  	   1   Basic file 	   0   Basic file
  	   2   Data array 	   1   Data array
  	   3   String array 	   2   String array
  	   4   Code file 	   3   Code file
  	   5   Snapshot 48K
  	   6   Microdrive file
  	   7   Screens$ file
  	   8   Special file
           9   Snapshot 128K
          10   Opentype file
          11   Execute file
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//realy needed? NO !// btw removing increases the file with 8 bytes
//#include <inttypes.h>
//#include <unistd.h>
//#include <sys/stat.h>
//#include <fcntl.h>

// are there official/common disc variables + their names ?
// z88dk/ ../mgt.d points to    mgt.c appmake.h ../common/dirname.h cpmdisk.h ff.h ffconf.h
// dan doore/ ../MGTman uses many ALMOST the same variables NAMES as i do, but used different

// values COULD be fetched from the interface with PEEK ((@x)+offset) (offset=2048?)

// these might change 
const int DDensity = 2         ; // single density=1 double density =2
const int DSides = 2           ; // singleside=1   doubleside=2
const int direntry=256         ; // LENGTH of 1 directory entry is 256 bytes, DD=512= 2 entries on 1 sector
const int sector_ln=256                       ; // standard length ??  3_1/2 =256     5_1/4 =128
const int sectorsize=512/*sector_ln * DDensity*/     ; // 1 sector=512 bytes max
const int tracksize=10                        ; // 1 track = 10 sectors
const int dirlen=4/*DDensity*DSides*/ ;
const int directorysize=80/*DDensity*dirlen*tracksize*/   ; // amount off tracks 4 tracks = 4 * 10 * DDensity

const int disc_DsDD= 160 /*40 * DDensity * DSides*/    ; // 80 tracks Double Sided Double Density=160tracks



int readMGT(char* filename) {

  FILE * fd= fopen(filename, "rb");  
  if (!fd) {
      printf("Error! opening file  %s", filename );
      return (0);
     }

  unsigned long filesize=0;
  fseek(fd, 0, SEEK_END);
  filesize = ftell(fd);
  fclose(fd);   // back to start off file

//  unsigned char* file_contents = malloc(filesize) ;

//my work
  char entry_str[513/*sectorsize+1*/] ;
  char* e_str    ; // erased or not
  char type_str[6+1] ; // TYPE on DISC  1-11
  char d_str[5+1]    ; // BLOCK TYPE on TAPE  0-3
  char param_1[25/*8+1*/] ;
  char param_2[8+1] ;
  char param_3[18/*8+1*/] ; // autostart line number
  char parameter_str[26+1] ;
  char sectormap[195+1];
  char file_sectormap[1560+1];
  char disk_sectormap[1560+1];

  char entryname[]={' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '\0'} ;
  char dataname , mapside ;

  unsigned int bit, bitnum, bn, nm, /*fnm, */ xm , filetype, bytecount, x, y, /*directorylength, */ dirsides, basvarlen;
  unsigned int allsectors, side, track, sector, entry, number, last, a ,length,  starttrack, startsector, d, e, start, g, h;

  unsigned int reg_hl, reg_hl2, reg_de, reg_de2, reg_bc, reg_bc2, reg_if, reg_ix, reg_iy, reg_if2 ,reg_sp ;

  /* directorylength = sectorsize * tracksize * directorysize */ ;

//  fseek(fd, 0, SEEK_SET);
//  fread(file_contents, filesize , 1 ,fd);

  printf("Found: %s\n",filename ) ;
  printf("filesize %lu ",filesize) ;
  if (filesize != 819200) printf(".. is NOT correct") ;

  printf("\n\n");
  printf(".)No |Filename   |Track |Sector>Amount |Block |Type | LOAD@|blocklen|param1 |param2 |param3 |Erased|\n") ;

  bytecount=0 ;
  number=0 ;     // directory entry 1-80  (0-79 on disk)
  last=0 ;       // reading from DISK involves loading a SECTOR with eg BASIC command  LOAD @ Driveno, Track, Sector, Address

// mind straight versus swopped tracks !!!!  *.IMG vs *.MGT
// dirsides=1 for DISCiPLE and dirsides=2 for +D/SAM  !both on an DoubleSides=2 disk!
// set all to '~' or '|' , since 32+1=33 to 32+80=122 < 124 and '~' and '|' are visible on the bitmap against ' ' a space.

  dirsides= 1 ;
  mapside= '~' ;
  for (x=0 ;x < 1560 ;x++){     // implement side 1='|' aka 124, and side 2='~' aka 126
    if (dirsides==1 && x>1560/2) mapside= '|' ;
    if (dirsides==2){
      xm = x % directorysize;  // every 10th ?? should be
      if (xm==0){
         if (x/directorysize % 2 == 1 ) mapside= '|' ; 
         if (x/directorysize % 2 == 0 ) mapside= '~' ; 
         }
      }// en side2
    disk_sectormap[x]= mapside ;
   }  // end x, write empty bitmap

  allsectors=0;
  while (last==0){
    for (side=0 ; side<dirsides ; side++) {
     for ( track=0 ; track< dirlen/dirsides ; track++) {
      for ( sector=0 ; sector<tracksize ; sector++) {

//this is the place to read a real sector @side,track,sector,adres if available, but needs adres and different repeat

  fd= fopen(filename, "rb");
  unsigned char* sector_contents = malloc(sectorsize) ;
  bytecount=track*tracksize*sectorsize +sector*sectorsize;
  fseek(fd, bytecount, SEEK_SET);
  fread(sector_contents, sectorsize , 1 ,fd);

     for (entry=0 ; entry < sectorsize ; entry=entry+direntry )   //entry=256 asfor singledensity and sectorsize=512 for doubledensity
       {
        number++ ;                                 // first raise to 1 , then use it(later)
//        bytecount=track*tracksize*sectorsize +sector*sectorsize + entry  ;
        for (x = 0 ; x < direntry+1 ; x++ )
           {
            entry_str[x] = sector_contents[x+entry] ;
           }//end x

        filetype=(unsigned int)(entry_str[0])  ;// filetype as by MGT

        for (x=0 ; x<10 ;x++) {
            entryname[x]=entry_str[x+1] ; // fetch actual file name, KEYWORDS not encountered (yet?)
            if (entryname[x]==0) entryname[x]=32;
            }  // end x entry_str[1]-entry_str[10]

        a          = 256*(unsigned int)(entry_str[11]) +(unsigned int)(entry_str[12]) ;// total sectors per entry , reversed endian
        allsectors = allsectors + a ;      // count total of sectors used   .. allsectors += a; // NEGATIVE ??

        starttrack = (unsigned int)(entry_str[13])  ; // start track
        startsector= (unsigned int)(entry_str[14])  ; // start sector
        d= (unsigned int)(entry_str[211]) ; // filetype as by TAPE

//bitmap is 160-4=156 x 10= 1560 sectors. 1560/8=195 bytes bitmap,
// starting side 1 from track 4, sector 1 to track 79 sector 10,
//          side 2 track 128, sector 1 to track 207, sector 10.
// from entry_str[15] to entry_str[209]

        for (x = 0 ; x < 195 ; x=x+5 )  // 5bytes of 8 = 40 sectors on a row
           {
            for (y=0 ; y < 5 ; y++ )// fetch 5 bytes
            {
            nm=x+y; //            printf(" %5d ",nm);
            sectormap[nm] = entry_str[nm+15] ;   // 15 is offset within directory entry AFTER name etc, but BEFORE type

            for (bit = 0 ; bit < 8; bit++)  // bitwise mapping bit 76543210 ?? left to right ?!?
                {
                 bitnum= nm*8;
                 bitnum= bitnum + 7- bit ; // bit 7= bitnum 0 , reversed!!  //   printf(" %5d ",bitnum);
                 bn=!!( (unsigned int)(sectormap[nm]) & (1<< (7-bit) ) ) ;      //   printf("%d",bn);

                 if ( bn==1  && file_sectormap[bitnum] == 0)
                      {
//                       fnm=number+32;
                       disk_sectormap[bitnum]= number+32 ; // 32+1='!',32+2='#' etc
                      }

                }//end bit
            }//end y                                                               //   printf("\n");
           }//end x

// 'length' has to be a 'long integer' on zx!!
        length   =(unsigned int)(entry_str[212]) + 256* (unsigned int)(entry_str[213]) + 65536* (unsigned int)(entry_str[210]) ;
        e        =(unsigned int)(entry_str[212]) + 256* (unsigned int)(entry_str[213]) ;
        start    =(unsigned int)(entry_str[214]) + 256* (unsigned int)(entry_str[215]) ;
        g        =(unsigned int)(entry_str[216]) + 256* (unsigned int)(entry_str[217]) ;
        h        =(unsigned int)(entry_str[218]) + 256* (unsigned int)(entry_str[219]) ;
        basvarlen= e-g ;
        dataname = ' ' ;   // DATA_NAME()    a() or a$() etc

//snapshot only
        reg_iy =(unsigned int)(entry_str[220]) + 256* (unsigned int)(entry_str[221]) ;/*"IY"*/
        reg_ix =(unsigned int)(entry_str[222]) + 256* (unsigned int)(entry_str[223]) ;/*"IX"*/
        reg_de2=(unsigned int)(entry_str[224]) + 256* (unsigned int)(entry_str[225]) ;/*"DE'"*/
        reg_bc2=(unsigned int)(entry_str[226]) + 256* (unsigned int)(entry_str[227]) ;/*"BC'"*/
        reg_hl2=(unsigned int)(entry_str[228]) + 256* (unsigned int)(entry_str[229]) ;/*"HL'"*/
        reg_if =(unsigned int)(entry_str[230]) + 256* (unsigned int)(entry_str[231]) ;/*"I+F"*/
        reg_de =(unsigned int)(entry_str[232]) + 256* (unsigned int)(entry_str[233]) ;/*"DE"*/
        reg_bc =(unsigned int)(entry_str[234]) + 256* (unsigned int)(entry_str[235]) ;/*"BC"*/
        reg_hl =(unsigned int)(entry_str[236]) + 256* (unsigned int)(entry_str[237]) ;/*"HL"*/
        reg_if2=(unsigned int)(entry_str[238]) + 256* (unsigned int)(entry_str[239]) ;/*"I+F"*/
        reg_sp =(unsigned int)(entry_str[240]) + 256* (unsigned int)(entry_str[241]) ;/*"SP"*/

        sprintf(param_1,"%s","        ");
        sprintf(param_2,"%s","        ");
        sprintf(param_3,"%s","        ");
        e_str = "      ";


switch(d) {
      case 0 :
             sprintf(d_str,"%d----",d);
             if (entry_str[1] !=0 ) sprintf(d_str,"%dBAS ",d); // 0= 1digit ,3digit BAS +1 space tab=5
             break;

      case 1 :
             sprintf(d_str,"%dD.AR",d);
             break;

      case 2 :
             sprintf(d_str,"%d$.AR",d);
             break;

      case 3 :
             sprintf(d_str,"%dCODE",d);
             break;

     default :
             sprintf(d_str, "%3d ?", d);
             break;
       }//end case d

switch(filetype) {
      case 0 :
             sprintf(type_str, "%2dNONE", filetype);
//             type_str="NONE" ;
             if (entry_str[1] !=0 )e_str="ERASED";
//                { e_str="ERASED";
//                  if (d<4)filetype= d+1 ; // rude rewrite of file type value, does it work IMMIDIATE like on this next "case" ??  NO, value increased BUT NOT USED
//                }
             break;

      case 1 :
             sprintf(type_str, "%2dBAS ", filetype);
//             type_str="BAS " ;
             sprintf(param_1, "| %5d ", g);
             sprintf(param_2, "+ %5d ", basvarlen);  // proglen+VarLeng |
             if ( h < 10000) sprintf(param_3," LINE %4d", h);
             break;

      case 2 :
             sprintf(type_str, "%2dD.AR", filetype);
//             type_str="D.AR";
             dataname=entry_str[216]-64; //DATA() NAME a() etc
             sprintf(param_1, "| DATA %c()", dataname);
             break;

      case 3 :
             sprintf(type_str, "%2d$.AR", filetype);
//             type_str="$.AR";
             dataname=entry_str[216]-128; //DATA() NAME a$() etc  +"$"
             sprintf(param_1, "| DATA %c$()", dataname);
             break;

      case 4 :
             sprintf(type_str, "%2dCODE", filetype);
//             type_str="CODE";
             if (h!=0) sprintf(param_1, "| autostart %5d ", h);
             break;

      case 5 :
             sprintf(type_str, "%2dSN48", filetype);
//             type_str="SN48";
             break;

      case 6 :
             sprintf(type_str, "%2dMDR ", filetype);
//             type_str="MDR ";
             break;

      case 7 :
             sprintf(type_str, "%2dSCR$", filetype);
//             type_str="SCR$";
             break;

      case 8 :
             sprintf(type_str, "%2dSPCL", filetype);
//             type_str="SPCL";
             break;

      case 9 :
             sprintf(type_str, "%2dSN28", filetype);
//             type_str="SN28";
             break;

      case 10 :
             sprintf(type_str, "%2dOPEN", filetype);
//             type_str="OPEN" ;
             sprintf(param_1, "|%7d", length);
             break;

      case 11 :
             sprintf(type_str, "%2dEXEC", filetype);
//             type_str="EXEC" ;
             break;

     default :
             sprintf(type_str,"%s", "      ");
//             type_str="    " ;
             break;
       }//end case t

// fill in the gabs, param_1+param_2+param_3
     strcpy(parameter_str,param_1);                   
     strcat(parameter_str,param_2);
     strcat(parameter_str,param_3);


// if next part is "selectable" then it needs a lot off "if statements" or "cases"
//   No |Filename   |Track |Sector>Amount |Block |Type |DT | LOAD@|blocklen|param1 |param2 |param3 |Erased |\n
  printf("%c)%2d",number+32,number) ;                  //No |
  printf("%c ",e_str[0]);                  // 'E' from erased file
  printf("%s ",&(entryname[0])) ;               // Filename   |
  printf("   %3d", starttrack) ;           // Track |
  printf("     %2d", startsector) ;        // Sector>
  printf("   %4d", a) ;                    //Amount |
  printf("   %s", d_str) ;                 // Block |
  printf(" %2d%s", filetype,type_str) ;    // Type |
  printf("  %5d", start) ;                 // LOAD@ |
  printf("  %6d", length) ;                // blocklen |
  printf(" %s", parameter_str ) ;          // 3x parameter |
  printf("  %s\n", e_str ) ;               //|Erased |

  if ( filetype==5 ||filetype==9) printf("   REGISTERS: reg_hl  %5d  reg_de  %5d  reg_bc  %5d  reg_if  %5d  reg_ix %5d  reg_iy%5d\n              reg_hl2 %5d  reg_de2 %5d  reg_bc2 %5d  reg_if2 %5d  reg_sp %5d\n",reg_hl, reg_de, reg_bc, reg_if, reg_ix, reg_iy, reg_hl2, reg_de2, reg_bc2, reg_if2 ,reg_sp );

  last=( a==0 || (entry_str[0]==0 && entry_str[1]==0) || number>=80); // name location contains zero, 80 needs to be replaced with MAX_Tracks, todo
  // all entry's are printed despite the 0 check??

      }// end entry

    fclose(fd) ; //readbin routine again
    free(sector_contents) ;

     }//  end sector
    }//   end track
   }//    end side , mind straight versus swopped tracks !!!!  *.IMG vs *.MGT
  }// end while last

printf("%d files on disk.\n" , number) ; // NOT CORRECT since it KEEPS counting until 80!!
printf("%d sectors used\n",allsectors);

for (x=0 ; x<1560 ; x++){
if (x%40 == 0 ) printf("\n");
printf("%c",disk_sectormap[x]);
}

//    fclose(fd) ; //readbin routine again
//    free(file_contents) ;
    return 0;
 }

int main(void/*int argc,char* argv[]*/)  // Command_line file input!!! // ./mgtDD_xxx  namefile.IMG
{
int counter , c ;

/* The zx spectrum target doesn't accept arguments as far as I know. Create some fake ones */
int argc = 2;
char *argv[3];

argv[0] = "./mgtDD243";
argv[1] = malloc(256);
argv[2] = NULL;

printf("Please enter a filename:\n");
memset(argv[1], 0, 256);
scanf("%255s", argv[1]);

printf("\nThis diskimage reader is for MGT DISCiPLE DISC formatted disks only , version: %s\n",argv[0]);
printf("reading the Directory only:\n");
if(argc==1) {
        printf("No Filenames passed\n\n");
        return 0 ;
       }

if(argc>=2){
        printf("Number of files passed: %d\n",argc-1);
        for(counter=1;counter<argc;counter++)
        printf("-%2d- %s\n",counter,argv[counter]) ;
       }
printf("\n");

for (c=1 ; c < counter ; c++) {
       char* filename = argv[c];  //disc must be DISCiPLE Disk
       readMGT( filename ) ;
       printf("\n\n");
      }

free(argv[1]);
return 0;
}





//---------------------------------------------------------------------

//  TESTDISK builder written in ZX Spectrum Basic
/*
   1 LET x$="1": CLOSE #*
   5 DIM y$(672): DIM z$(6*672): LET y$()="This is a testdisk utility that writes (almost) all 11 differentfile types know to the          MGT DISCiPLE Diskdrive (3d)     which types consist off         4 BASIC files, 2 DATA files,    2 CODE files, 2SCREEN$ files    2 48k SNAPshots, 2 128 SNAPshots1 EXEcutefile and TWO OPENtype  files from which 1 will use thistext in order to be written to  disk by the 'OPEN #' statement  using stream #4,#5 and #15 as a channel device to the disk in   diskdrive1                      the next to be written file is :"
   6 LET z$=y$+y$+y$+y$+y$+y$
   7 OPEN #15;d*;"DisK#15" OUT : REM type 10
  20 DIM x(5e3): LET a=4e4: LET p=PEEK a
  30 RESTORE 
  40 READ a$: PRINT #15;z$;a$: SAVE d*;a$: REM type 1+var
  50 READ b$: PRINT #15;z$;b$: SAVE d*;b$ DATA x(): REM type 2
  60 READ c$: PRINT #15;z$;c$: SAVE d*;c$ DATA z$(): REM type 3
  70 CAT *!
  80 READ d$: PRINT #15;z$;d$: SAVE d*;d$CODE 16384,6912: REM type 4
  90 READ e$: PRINT #15;z$;e$: POKE 16384,201: SAVE d*;e$CODE 16384,1,16384: REM type 4 autostart
 100 READ f$: PRINT #15;z$;f$: SAVE d*;(f$)S: REM type 5
 110 READ g$: PRINT #15;z$;" NOT yet ";g$:: REM type 6
 120 READ h$: PRINT #15;z$;h$: SAVE d*;h$SCREEN$ : REM type 7
 130 READ i$: PRINT #15;z$;"NOT yet ";i$:: REM type 8
 140 READ j$: PRINT #15;z$;j$: SAVE d*;(j$)K: REM type 9
 150 READ k$: PRINT #15;z$;k$: OPEN #4;d*;(k$) OUT : REM type 10
 160 PRINT #4;x$;" This is a test DISK !"+CHR$ 13: LIST #4
 170 CLOSE #*4
 180 READ l$: PRINT #15;z$;l$: POKE a,201: SAVE d*;(l$)X,a: POKE a,p: REM type 11
 190 READ m$: PRINT #15;z$;m$: SAVE d*;m$ LINE 1: REM type 1+var+LINE
 200 READ n$: PRINT #15;z$;n$: ERASE d*;k$ TO ;n$
 210 OPEN #5;d*;(n$)IN 
 220 INPUT #5;u$
 230 PRINT u$
 240 CLOSE #*5
 250 ERASE d*;n$ TO "Test.OUT."+x$
 260 IF x$="1" THEN  LET x$="2": GO TO 30
 265 CLOSE #*15
 270 CLEAR 
 280 SAVE d*"MKdiskDD3": SAVE d*"MKdiskDD4" LINE 9999: REM type 1,type 1+LINE
 290 FOR f=1 TO 10: BEEP .1,.5: BEEP .1,.1: NEXT f
 300 PRINT #0;AT 0,0;"PRESS NMI THEN 3 AND NMI THEN 4"'" THEN KEY X      !!avoid NMI+5!!": PAUSE 0: IF INKEY$<>"x" AND INKEY$<>"X" THEN  GO TO 300
 310 BEEP .5,35: LET x$="2"
 320 RESTORE : READ a$,b$,c$,d$,e$,f$,g$,h$,i$,j$,k$,l$,m$,n$
 330 ERASE d*;a$
 340 ERASE d*;b$
 350 ERASE d*;c$
 360 ERASE d*;d$
 370 ERASE d*;e$
 380 ERASE d*;f$
 390 REM : ERASE d*;g$
 400 ERASE d*;h$
 410 REM : ERASE d*;i$
 420 ERASE d*;j$
 430 REM : ERASE d*;k$
 440 ERASE d*;m$
 450 REM : ERASE d*;n$
 460 STOP : DATA "MKdiskDD_"+x$,"data x  _"+x$,"data z$ _"+x$,"Screen  _"+x$,"self_RUN_"+x$,"snap 48k_"+x$,"6       _"+x$,"Screen$ _"+x$,"8       _"+x$,"snap128k_"+x$,"Test OUT_"+x$,"NOT exec_"+x$,a$( TO 8)+"L"+x$,"tEST IN _"+x$
 470 POKE @5,255: POKE @10,0: LPRINT CHR$ 27;CHR$ 10;CHR$ 27;CHR$ 13: LLIST 
 480 REM zmakebas MKdiskDD_0037.txt -n MKdiskDD -o MKdiskDD_0037.tap
*/
