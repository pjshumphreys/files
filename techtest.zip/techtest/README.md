To use this code run these commands:

```
npm install
export TECH_TEST_YT_API_KEY=[your youtube api key]
node index.js
```

then point your web browser at localhost port 3000
