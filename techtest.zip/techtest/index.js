const fs = require('fs').promises;

Promise.all([
  import('node-fetch').then(fetch => fetch['default']),
  (new Promise(resolve => {
    if(typeof(process.env.TECH_TEST_YT_API_KEY) === 'string' && process.env.TECH_TEST_YT_API_KEY !== '') {
      resolve(process.env.TECH_TEST_YT_API_KEY);
    }
    else {
      throw('You need to set the TECH_TEST_YT_API_KEY environment variable to your youtube API key');
    }
    
  })),
  fs.readFile('./client.html', 'utf-8')
])
.then(imports => {
  const fetch = imports[0];
  const express = require('express');
  const app = express();
  const port = 3000;
  const youtubeApiKey = imports[1];
  
  const client = imports[2];

  app.get('/', (req, res) => res.send(client));
  
  app.get('/search/:searchTerm', async (req, res) => {
    const searchTerm = req.params.searchTerm; 
    
    results = await Promise.all([
      //flickr
      (async () => {
        const res = await fetch(`https://www.flickr.com/services/feeds/photos_public.gne?format=json&nojsoncallback=1&tags=${searchTerm}`);
        const data = await res.json();

        const input = data?.items || [];
        const len = input.length;
        const output = [];

        for(let i = 0; i< len; i++) {
          const url = input[i]?.media?.m;

          if(typeof(url) === 'string') {
            output.push(url);
            
            if(output.length === 3) {
              break;
            }
          }
        }

        return output;
      })(),

      //youtube
      (async () => {
        const res = await fetch(`https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=10&q=${searchTerm}&type=video&key=${youtubeApiKey}`);
        const data = await res.json();

        const input = data?.items || [];
        const len = input.length;
        const output = [];

        for(let i = 0; i< len; i++) {
          const videoId = input[i]?.id?.videoId;

          if(typeof(videoId) === 'string') {
            output.push(`https://www.youtube.com/embed/${videoId}`);
            
            if(output.length === 1) {
              break;
            }
          }
        }

        return output;
      })()
    ]).
      then(results => {
        res.setHeader('Content-Type', 'application/json');
        res.end(JSON.stringify({
          searchTerm,
          flickr:results[0],
          youtube: results[1] 
        }, null, 2));
      });
  });
  

  app.listen(port, () => {
    console.log(`Example app listening on http://localhost:${port}`);
  });
})
.catch(error => {
  console.log("Couldn't load prerequisites:\n", error);
});
