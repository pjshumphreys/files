QueryCSV is a command line application to query files containing comma
separated values (csv files) using files containing sql like query syntax.

This archive contains pre built executables for each supported platform:

querycsv : static linux build
qrycsvw.exe : win32 build
querycsv.exe : dos build
querycsv.ttp : atari st build (ttp means a command line tool with parameters)
html5/querycsv : html5 build
mac68k.dsk : classic mac os build
powermac.dsk : power pc/carbon mac os build
amiga.adf : amiga os build
riscos.adf : riscos build

The mac68k, powermac, amiga and risc os folders contain disk images as the
default filesystems on those platforms contain extra metadata that is
essential for the program to run. These will either need to be written to a
real disk somehow or used with an emulator.

The HTML5 build is a collection of files that should be hosted on the root
level of a web domain. Only a static file serving capability is needed though
as the files a user 'uploads' are actually stored in their browser cache
using IndexedDB.

For more infomation about QueryCSV, see:

  https://github.com/pjshumphreys/querycsv
