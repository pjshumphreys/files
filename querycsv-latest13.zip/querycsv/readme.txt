QueryCSV is a command line application to query files containing comma
separated values (csv files) using files containing sql like query syntax.

-----------------------------------------------------------------------------

This archive contains pre built executables for each supported platform:

querycsv: x86 linux build (statically compiled)
querycsv.arm : static 32 bit arm linux build (works on the Raspberry Pi and Android)
querycsv.exe : win32 build
qrycsv16.exe : dos build
querycsv.ttp : atari st build (ttp means a command line tool with parameters)
html5/ : html5 build
cpm/ : the cpm/msx-dos build. See below for details.
m68kmac.bin : classic mac os build (in a MacBinary archive) compatable with System 6.0.8
powermac.bin : power pc/carbon mac os build (in a MacBinary archive)
amiga.adf : amiga os build
!QueryCSV/ : riscos build
bbcarm.adl : build for the ARM Evaluation System add-on for the BBC Micro
querycsv.crt : an easyflash cartridge image for the Commodore 64
zx/ : zx spectrum build in various formats. See below for more details

-----------------------------------------------------------------------------

The amiga and bbcarm builds are disk images as the default filesystems on
those platforms contain extra metadata that is essential for the program
to run. These will either need to be written to a real disk somehow or
used with an emulator.

-----------------------------------------------------------------------------

The HTML5 build is a collection of files that should be hosted on the root
level of a web domain. Only a static file serving capability is needed though
as the files a user 'uploads' are actually stored in their browser cache
using IndexedDB.

-----------------------------------------------------------------------------

The CP/M build should work for all CP/M and MSXDOS based systems. However,
If an MSX2 memory mapper is detected the program will use this memory to
speed up operation.

MSX1 computers can also use an MSX2 compatible memory mapper by first running
MU.COM, which is available at
  https://www.msx.org/downloads/mu-v105-with-manual-translated

The *.ovl files must all be in the same location as querycsv.com

To initialise the memory mapper on MSXDOS2, first run

  ramdisk 1024
  
or on MSXDOS1, first run
  
  mu 1024

-----------------------------------------------------------------------------

The ZX Spectrum build supports the esxdos, residos and plus3dos disk systems.
The zx/ folder contains the following files:

archive/ : Contains the files stored in archive.tap so that they can be copied
  to a fat formatted sd disk directly. These files contain the program code
  that must be present in the root directory of the disk system in use.
archive.tap: Contains the program code in a format that can be read from tape
  using one of esxdos.tap, plus3dos.tap or residos.tap 
residos.tap : A loader program for residos systems that can unarchive the
  contents of archive.tap from tape onto a residos drive
plus3dos.tap : A loader program for plus3dos systems that can unarchive the
  contents of archive.tap from tape onto a plus3dos drive
plus3dos.tap : A loader program for esxdos systems (such as the divmmc) that
  can unarchive the contents of archive.tap from tape onto an esxdos drive

To load the zx files onto your disk, first switch to the appropriate .tap file
for your disk system (residos.tap, esxdos.tap or plus2dos.tap), then enter

  LOAD ""

at the spectrum's prompt. The loaded program will then wait for you to switch
to archive.tap. After you've done the switch press the drive letter you like
to extract the files to (or any other key to use the current drive). You may
need to pause the archive.tap file after each block has been read until the
disk has been updated.

After that has been done, you can load the "querycsv" program in the regular
manner: i.e for esxdos/divmmc systems use:

  LOAD *"querycsv"
  
for residos systems use:

  LOAD %"querycsv"
  
or for plus3dos systems use:

  LOAD "querycsv"

-----------------------------------------------------------------------------

For more infomation about QueryCSV, see:

  https://github.com/pjshumphreys/querycsv
