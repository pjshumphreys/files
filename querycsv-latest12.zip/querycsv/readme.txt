QueryCSV is a command line application to query files containing comma
separated values (csv files) using files containing sql like query syntax.

This archive contains pre built executables for each supported platform:

querycsv: x86 linux build (statically compiled)
querycsv.arm : static 32 bit arm linux build (works on the Raspberry Pi and Android)
querycsv.exe : win32 build
qrycsv16.exe : dos build
querycsv.ttp : atari st build (ttp means a command line tool with parameters)
html5/ : html5 build
m68kmac.bin : classic mac os build (in a MacBinary archive) compatable with System 6.0.8
powermac.bin : power pc/carbon mac os build (in a MacBinary archive)
amiga.adf : amiga os build
!QueryCSV/ : riscos build
bbcarm.adl : build for the ARM Evaluation System add-on for the BBC Micro
querycsv.crt : an easyflash cartridge image for the Commodore 64
zx/ : zx spectrum build in various formats

The amiga and bbcarm builds are disk images as the default filesystems on
those platforms contain extra metadata that is essential for the program
to run. These will either need to be written to a real disk somehow or
used with an emulator.

The HTML5 build is a collection of files that should be hosted on the root
level of a web domain. Only a static file serving capability is needed though
as the files a user 'uploads' are actually stored in their browser cache
using IndexedDB.

The ZX Spectrum build supports the esxdos, residos and plus3dos disk systems. The zx/ folder contains the following files:

qcsv**zx.ovl : These files contain the program code in must be present in the root directory of the disk system in use
querycsv.tap : The launcher program as a .tap file
querycsv : The launcher program as a plus3dos program
residos.tap : Contains a .tap archive of the querycsv.tap and qcsv**zx.ovl files
unarchive.tap : A program to extract the contents of residos.tap onto a residos hard drive
plus3dos.dsk : a 720k plus3dos formatted disk image containing the querycsv and qcsv**zx.ovl files for use with plus3dos

For esxdos, just copy qcsv**zx.ovl and querycsv.tap onto your hard drive/sd card's root folder.

For more infomation about QueryCSV, see:

  https://github.com/pjshumphreys/querycsv
